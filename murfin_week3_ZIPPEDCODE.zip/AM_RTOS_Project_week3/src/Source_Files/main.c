/***************************************************************************//**
 * @file
 * main.c
 *
 * @brief
 * Andrew Murfin's ECEN3753 SP21 Project Rev 0
 *
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "em_device.h"
#include "em_chip.h"
#include "em_emu.h"
#include "bsp.h"
#include "main.h"
#include "app.h"
#include "gpio.h"
#include "capsense.h"
#include "display.h"
#include "textdisplay.h"
#include "retargettextdisplay.h"

// Micrium OS Includes
#include  <bsp_os.h>
#include  "bsp.h"
#include  <cpu/include/cpu.h>
#include  <common/include/common.h>
#include  <kernel/include/os.h>
#include  <kernel/include/os_trace.h>
#include  <common/include/lib_def.h>
#include  <common/include/rtos_utils.h>
#include  <common/include/toolchains.h>

volatile uint32_t msTicks; /* counts 1ms timeTicks */

/* LOCAL TASK STATIC PROTOTYPES */
static  void  MainStartTask (void  *p_arg);
static  void  IdleTask (void  *p_arg);
static  void  SvcPhysicsTask (void  *p_arg);
static  void  LCDGraphicsTask (void  *p_arg);
static  void  MeasureCapsenseTask (void  *p_arg);
static  void  ButtonInLED0OutTask (void  *p_arg);
static  void  LED1OutTask (void  *p_arg);

static	void  SvcPhysicsTimerCallback (OS_TMR p_tmr, void * p_arg);
static	void  LCDGraphicsTimerCallback (OS_TMR p_tmr, void * p_arg);
static	void  MeasureCapsenseTimerCallback (OS_TMR p_tmr, void * p_arg);
static	void  LED1BlinkTimerCallback (OS_TMR p_tmr, void * p_arg);

// Micrium OS Task Objects
/* Start Task Stack.                                    */
static  CPU_STK  	MainStartTaskStk[MAIN_START_TASK_STK_SIZE];
/* Start Task TCB.                                      */
static  OS_TCB   	MainStartTaskTCB;
/* Idle Task Stack.                                    */
static  CPU_STK  	IdleTaskStk[IDLE_TASK_STK_SIZE];
/* Idle Task TCB.                                      */
static  OS_TCB   	IdleTaskTCB;
/* Service Physics Task Stack.                                    */
static  CPU_STK  	SvcPhysicsTaskStk[SVC_PHYSICS_TASK_STK_SIZE];
/* Service Physics Task TCB.                                      */
static  OS_TCB   	SvcPhysicsTaskTCB;
/* LCD Graphics Task Stack.                                    */
static  CPU_STK  	LCDGraphicsTaskStk[LCD_GRAPHICS_TASK_STK_SIZE];
/* LCD Graphics Task TCB.                                      */
static  OS_TCB   	LCDGraphicsTaskTCB;
/* Measure Capsense Task Stack.                                    */
static  CPU_STK  	MeasureCapsenseTaskStk[MEASURE_CAPSENSE_TASK_STK_SIZE];
/* Measure Capsense Task TCB.                                      */
static  OS_TCB   	MeasureCapsenseTaskTCB;
/* Button In, LED0 Output Task Stack.                                    */
static  CPU_STK  	ButtonInLED0OutTaskStk[BTN_IN_LED0_OUT_TASK_STK_SIZE];
/* Button In, LED0 Output Task TCB.                                      */
static  OS_TCB   	ButtonInLED0OutTaskTCB;
/* LED 1 Output Task Stack.                                    */
static  CPU_STK  	LED1OutTaskStk[LED1_OUT_TASK_STK_SIZE];
/* LED 1 Output Task TCB.                                      */
static  OS_TCB   	LED1OutTaskTCB;

// Other Micrium OS Objects
// OS Timers
static	OS_TMR			SvcPhysicsTimer;
static	OS_TMR			LCDGraphicsTimer;
static	OS_TMR			MeasureCapsenseTimer;
static	OS_TMR			LED1BlinkTimer;
// Semaphores
static	OS_SEM			SvcPhysicsTimerSem;
static	OS_SEM			LCDGraphicsTimerSem;
static	OS_SEM			MeasureCapsenseTimerSem;
static	OS_SEM			LED1BlinkTimerSem;
// Flags
static	OS_FLAG_GRP		LED1OutFlags;	// b0 = "FLAG_XMAX_VIOLATION, b1 = "FLAG_PENDLM_FELL_VIOLATION"
// Locks
static 	OS_MUTEX		PendulumParamsLock;
// MsgQ
static	OS_Q			ButtonInLED0OutMsgQ;

// Instantiation of shared data structs
static	PendulumParams	rodParams;

//////////// NON OS FUNCTIONS ////////////

/**
 * @brief
 * OS Helper Function - posts to ButtonInLED0OutMsgQ with the button pushed.
 *
 * @param[in] btn
 * The button pushed
 *
 * @notes
 * Called by GPIO ISR
 *
 */
void postBtnMsgQ(pressedButton btn)
{
	RTOS_ERR err;
	ButtonMessage msg;
	// post to msgQ
	msg.button = btn;
	OSQPost(&ButtonInLED0OutMsgQ,
			(void *)&msg,
			(OS_MSG_SIZE)sizeof(void *),
			(OS_OPT_POST_ALL + OS_OPT_POST_FIFO),
			&err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * Initialize values in rodParams to default states
 *
 */
void initRodParams(void)
{
	// TODO figure out better initial values
	rodParams.pendulumBallVelocX = 0;
	rodParams.pendulumBallVelocY = 0;
	rodParams.pendulumBallX = 0;
	rodParams.pendulumBallY = 0;
	rodParams.pendulumBaseX = 0;
	rodParams.pendulumTheta = 0;
	rodParams.pendulumForceGain = FORCE_GAIN_NONE;
	rodParams.pendulumForce = 0;
}

int main(void) {
	  RTOS_ERR err;
	  BSP_SystemInit();
	  CPU_Init();                                                 /* Initialize CPU.                                      */

	  OS_TRACE_INIT();
	  OSInit(&err);                                               /* Initialize the Kernel.                               */
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  // add startupt task & start OS kernel
	  OSTaskCreate(&MainStartTaskTCB,                          /* Create the Start Task.                               */
	               "Main Start Task",
	                MainStartTask,
	                DEF_NULL,
	                MAIN_START_TASK_PRIO,
	               &MainStartTaskStk[0],
	               (MAIN_START_TASK_STK_SIZE / 10u),
	                MAIN_START_TASK_STK_SIZE,
	                0u,
	                0u,
	                DEF_NULL,
	               (OS_OPT_TASK_STK_CLR),
	               &err);
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  OSStart(&err);                                              /* Start the kernel.                                    */
	  /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  return 1;
}

/**
 * @brief
 * Service Physics timer callback function
 *
 * @details
 * Posts to semaphore for periodic servicing of pendulum physics
 */
static	void  SvcPhysicsTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&SvcPhysicsTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * LCD Graphics timer callback function
 *
 * @details
 * Posts to semaphore for periodic servicing of LCD Graphics
 */
static	void  LCDGraphicsTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&LCDGraphicsTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * Measure Capsense timer callback function
 *
 * @details
 * Posts to semaphore for periodic servicing of capsense measurements
 */
static	void  MeasureCapsenseTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&MeasureCapsenseTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * LED1 Blink Timer Callback
 *
 * @details
 * Periodic timer @ 1Hz, for use when there is an xmax violation and
 * the OS freezes the game in a 1Hz LED1 blink routine until reset
 */
static	void  LED1BlinkTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&LED1BlinkTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

//////////// OS FUNCTIONS ////////////
/*
*********************************************************************************************************
*                                          MainStartTask()
*
* Description : This is the task that will be called by the Startup when all services are initializes
*               successfully.
*
* Argument(s) : p_arg   Argument passed from task creation. Unused, in this case.
*
* Return(s)   : None.
*
* Notes       : None.
*********************************************************************************************************
*/
static  void  MainStartTask (void  *p_arg)
{
    RTOS_ERR  err;


    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    Common_Init(&err);                                          /* Call common module initialization example.           */
    APP_RTOS_ASSERT_CRITICAL(err.Code == RTOS_ERR_NONE, ;);

	EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
	CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;


	CHIP_Init();


	EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
	EMU_DCDCInit(&dcdcInit);
	em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
	EMU_EM23Init(&em23Init);
	CMU_HFXOInit(&hfxoInit);


	CMU_OscillatorEnable(cmuOsc_HFRCO, true, true);
	CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
	CMU_OscillatorEnable(cmuOsc_HFXO, false, false);


	CMU_ClockEnable(cmuClock_GPIO, true);

    app_peripheral_setup();

    /* Initialize the display module. */
    DISPLAY_Init();

    /* Retarget stdio to a text display. */
    if (RETARGET_TextDisplayInit() != TEXTDISPLAY_EMSTATUS_OK) {
      while (1) ;
    }

    // Initialize rodParams variables to default state
    initRodParams();

	// CREATE ALL OS OBJECTS (3x timers, 4x sems, 1x mutex, 1x flaggrp)
    // FLAGS
	// LED1 Output Flag Group
	OSFlagCreate(&LED1OutFlags,
				"LED1 Output Flags",
				EVENT_FLAGS_INITILZIED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// SEMAPHORES
	// Service Physics Timer semaphore
	OSSemCreate(&SvcPhysicsTimerSem,
				"Service Physics Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Grahpics Timer semaphore
	OSSemCreate(&LCDGraphicsTimerSem,
				"LCD Grahpics Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Timer semaphore
	OSSemCreate(&MeasureCapsenseTimerSem,
				"Measure Capsense Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// MUTEXs
	// Pendulum Params Mutex
	OSMutexCreate(&PendulumParamsLock,
				"Pendulum Params Mutex",
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// TIMERS
	// Service Physics Timer
	OSTmrCreate(&SvcPhysicsTimer,
			   "Service Physics Timer",
			   TIMER_NO_DELAY,
			   TIMER_SVC_PHYSICS_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &SvcPhysicsTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Graphics Timer
	OSTmrCreate(&LCDGraphicsTimer,
			   "LCD Graphics Timer",
			   TIMER_NO_DELAY,
			   TIMER_LCD_GRAPHICS_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &LCDGraphicsTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Timer
	OSTmrCreate(&MeasureCapsenseTimer,
			   "Measure Capsense Timer",
			   TIMER_NO_DELAY,
			   TIMER_MEASURE_CAPSENSE_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &MeasureCapsenseTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED1 Blink Timer
	OSTmrCreate(&LED1BlinkTimer,
			   "LED1 Blink Timer",
			   TIMER_NO_DELAY,
			   TIMER_LED1_BLINK_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &LED1BlinkTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// MSG QUEUES
	// Button Input / LED0 Output Queue
	OSQCreate(&ButtonInLED0OutMsgQ,
			  "Button Input / LED0 Output Msg Queue",
			  BTN_IN_LED0_OUT_MAX_MSGQ_QTY,
			  &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // CREATE ALL OTHER TASKS
	// Idle Task Create
	OSTaskCreate(&IdleTaskTCB,
			   "Idle Task",
				IdleTask,
				DEF_NULL,
				IDLE_TASK_PRIO,
			   &IdleTaskStk[0],
			   (IDLE_TASK_STK_SIZE / 10u),
				IDLE_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Service Physics Task Create
	OSTaskCreate(&SvcPhysicsTaskTCB,
			   "Service Physics Task",
			   SvcPhysicsTask,
			   DEF_NULL,
				SVC_PHYSICS_TASK_PRIO,
			   &SvcPhysicsTaskStk[0],
			   (SVC_PHYSICS_TASK_STK_SIZE / 10u),
			   SVC_PHYSICS_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Graphics Task Create
	OSTaskCreate(&LCDGraphicsTaskTCB,
			   "Speed Setpoint Task",
			   LCDGraphicsTask,
			   DEF_NULL,
			   LCD_GRAPHICS_TASK_PRIO,
			   &LCDGraphicsTaskStk[0],
			   (LCD_GRAPHICS_TASK_STK_SIZE / 10u),
			   LCD_GRAPHICS_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Task Create
	OSTaskCreate(&MeasureCapsenseTaskTCB,
			   "Measure Capsense Task",
			   MeasureCapsenseTask,
			   DEF_NULL,
			   MEASURE_CAPSENSE_TASK_PRIO,
			   &MeasureCapsenseTaskStk[0],
			   (MEASURE_CAPSENSE_TASK_STK_SIZE / 10u),
			   MEASURE_CAPSENSE_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Button In / LED0 Out Task Create
	OSTaskCreate(&ButtonInLED0OutTaskTCB,
			   "Button In / LED0 Out Task",
			   ButtonInLED0OutTask,
			   DEF_NULL,
			   BTN_IN_LED0_OUT_TASK_PRIO,
			   &ButtonInLED0OutTaskStk[0],
			   (BTN_IN_LED0_OUT_TASK_STK_SIZE / 10u),
			   BTN_IN_LED0_OUT_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED1 Output Task Create
	OSTaskCreate(&LED1OutTaskTCB,
			   "LED1 Output Task",
			   LED1OutTask,
			   DEF_NULL,
			   LED1_OUT_TASK_PRIO,
			   &LED1OutTaskStk[0],
			   (LED1_OUT_TASK_STK_SIZE / 10u),
			   LED1_OUT_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // delete self task & check error code
    OSTaskDel(NULL, &err);
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief OS Idle Task - custom implementation
 *
 * @details Goes into EM1
 */
static void IdleTask(void *p_arg)
{
    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    while (INFINITE_LOOP)
    {
    	EMU_EnterEM1();
    }
}

/**
 * @brief
 * Service Physics Task
 *
 * @details
 * Task runs every Tphy (TIMER_SVC_PHYSICS_PERIOD).  Services physics for
 * Inverted Pendulum game
 *
 */
static void	SvcPhysicsTask(void * p_arg)
{
    RTOS_ERR  	err;
    CPU_BOOLEAN tmrStartSuccess;
    // values to be READ from rodParams
    int32_t		currPendulumBallVelocX;
    int32_t 	currPendulumBallVelocY;
    int32_t 	currPendulumBallX;
    int32_t 	currPendulumBallY;
    int32_t 	currPendulumBaseX;
    int8_t 		currPendulumTheta;
    uint16_t 	currPendulumForceGain;
    int32_t	 	currPendulumForce;
    // values to be WRITTEN to rodParams
    int32_t 	nextPendulumBallVelocX;
    int32_t		nextPendulumBallVelocY;
    int32_t		nextPendulumBallX;
    int32_t 	nextPendulumBallY;
    int32_t 	nextPendulumBaseX;
    int8_t		nextPendulumTheta;
    // local values for calculations
    int32_t 	currPendulumAccelX;
    int32_t		currPendulumAccelY;
    bool		thetaShift;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // Start Periodic Physics Servicing Timer
    tmrStartSuccess = OSTmrStart(&SvcPhysicsTimer,
    		   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// UNIT TEST 9A: confirming timer started
	if (tmrStartSuccess == DEF_FALSE)
		while(INFINITE_LOOP);

    while (INFINITE_LOOP)
    {
    	// re-clear theta shift flag
    	thetaShift = false;
    	// Pend on timer semaphore
    	OSSemPend(&SvcPhysicsTimerSem,
    			  SEM_PEND_FOREVER,
				  OS_OPT_PEND_BLOCKING,
				  NULL,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Read vars from rodParams, quickly
    	currPendulumBallVelocX = rodParams.pendulumBallVelocX;
    	currPendulumBallVelocY = rodParams.pendulumBallVelocY;
    	currPendulumBallX = rodParams.pendulumBallX;
    	currPendulumBallY = rodParams.pendulumBallY;
    	currPendulumBaseX = rodParams.pendulumBaseX;
    	currPendulumTheta = rodParams.pendulumTheta;
    	currPendulumForceGain = rodParams.pendulumForceGain;
    	currPendulumForce = rodParams.pendulumForce;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// calculate new values for rodParams
    	// TODO add math libs
    	// TODO ensure normalcy in regards to signs/direction of forces (FUNCTIONAL TEST 6)
    	// based on force, calculate TOTAL ACCELERATION
    	currPendulumAccelX = MASS_BALL * ((currPendulumForce * (1 - cos(2 * currPendulumTheta))) / 2);
    	currPendulumAccelY = MASS_BALL * (((currPendulumForce * sin(2 * currPendulumTheta)) / 2) + (MASS_BALL * ACCEL_GRAVITY));
    	// based on accelration, previous velocity, calculate new velocity
    	nextPendulumBallVelocX = currPendulumBallVelocX + ((SVC_PHY_DELTA_T) * currPendulumAccelX);
    	nextPendulumBallVelocY = currPendulumBallVelocY + ((SVC_PHY_DELTA_T) * currPendulumAccelY);
    	// based on old position of ball and new velocity, calculate new position of ball
    	nextPendulumBallX = currPendulumBallX + (SVC_PHY_DELTA_T * nextPendulumBallVelocX);
    	nextPendulumBallY = currPendulumBallY + (SVC_PHY_DELTA_T * nextPendulumBallVelocY);
    	// clamp y value
    	if (nextPendulumBallY > LENGTH_POST)
    		nextPendulumBallY = LENGTH_POST;
    	// identify "theta shift" boundary condition
    	if ((LENGTH_POST - currPendulumBallY <= BALL_Y_THETA_SHIFT)
    		&& (currPendulumBallVelocY > 0 || currPendulumBallVelocY == 0)
			&& (nextPendulumBallVelocY < 0))
    		thetaShift = true;
    	// compute new theta, and base x-position
    	if (currPendulumBallY == LENGTH_POST)
    		nextPendulumTheta = 0;
    	else
    		// TODO fix sign shift
    		nextPendulumTheta = cos^-1(nextPendulumBallY/LENGTH_POST);

    	nextPendulumBaseX = 0;	// TODO real calculations
    	nextPendulumTheta = 0;	// TODO real calculations
    	// UNIT TEST 7: service physics properly calculating
    	if (nextPendulumBaseX != 0 || nextPendulumTheta != 0)
    		while (INFINITE_LOOP);

    	// Check for "pendulumFell" violation
    	// if found, set flag to be processed by LED1OutTask
    	// UNIT TEST 1: Testing Theta Boundary Conditions
    	if (((nextPendulumTheta > 0) && (nextPendulumTheta >= (int32_t)VIOLATION_PENDULUM_FELL))
    	    || ((nextPendulumTheta < 0) && (nextPendulumTheta <= (int32_t)(VIOLATION_PENDULUM_FELL * -1))))
    	{
    		OSFlagPost(&LED1OutFlags,
    				   FLAG_PENDLM_FELL_VIOLATION,
					   OS_OPT_POST_FLAG_SET,
					   &err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    	}
    	// Check for "xmax" violation
    	// if found, set flag to be processed by LED1OutTask
    	// UNIT TEST 2: Testing Xmax & XMin Boundary Conditions
    	// TODO figure out xmax & xmin values
    	if ((nextPendulumBaseX >= VIOLATION_XMAX) || (nextPendulumBaseX <= VIOLATION_XMIN))
    	{
    		OSFlagPost(&LED1OutFlags,
    				   FLAG_XMAX_VIOLATION,
					   OS_OPT_POST_FLAG_SET,
					   &err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    	}

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Enter new values in to rodParams
    	rodParams.pendulumBaseX = nextPendulumBaseX;
    	rodParams.pendulumTheta = nextPendulumTheta;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    }
}

/**
 * @brief
 * LCD Graphics Task
 *
 * @details
 * Periodic task that runs every Tlcd (TIMER_LCD_GRAPHICS_PERIOD).
 * Updates LCD Graphics Display based on latest location of rod
 * in rodParams.
 *
 */
static void	LCDGraphicsTask(void * p_arg)
{
    RTOS_ERR  err;
    CPU_BOOLEAN tmrStartSuccess;
    int32_t currPendulumBaseX;
    int8_t	currPendulumTheta;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // Start Periodic Timer to Svc LCD Graphics
    tmrStartSuccess = OSTmrStart(&LCDGraphicsTimer,
    		   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// UNIT TEST 9B: confirming timer started
	if (tmrStartSuccess == DEF_FALSE)
		while(INFINITE_LOOP);

    while (INFINITE_LOOP)
    {
    	// Pend on timer sem
    	OSSemPend(&LCDGraphicsTimerSem,
    			  SEM_PEND_FOREVER,
				  OS_OPT_PEND_BLOCKING,
				  NULL,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Quickly get vars from rodParams
    	currPendulumBaseX = rodParams.pendulumBaseX;
    	currPendulumTheta = rodParams.pendulumTheta;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// TODO update display
    }
}

/**
 * @brief
 * Measure Capsense Task
 *
 * @details
 * Periodic every Tcap (TIMER_MEASURE_CAPSENSE_PERIOD)
 * Measures user input on capsense slider, and updates
 * "pendulumForce" variable in rodParams
 *
 */
static void	MeasureCapsenseTask(void * p_arg)
{
    RTOS_ERR  err;
    CPU_BOOLEAN tmrStartSuccess;
    int32_t sliderPositionRaw;
    uint16_t currPendulumForce;
    static uint16_t lastPendulumForce = SLIDER_NO_FORCE;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // initialize CAPSENSE module
    CAPSENSE_Init();

    // Start Periodic Timer to Measure Capsense Input
    tmrStartSuccess = OSTmrStart(&MeasureCapsenseTimer,
    		   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// UNIT TEST 9C: confirming timer started
	if (tmrStartSuccess == DEF_FALSE)
		while(INFINITE_LOOP);

    while (INFINITE_LOOP)
    {
    	// Pend on timer sem
    	OSSemPend(&MeasureCapsenseTimerSem,
    			  SEM_PEND_FOREVER,
				  OS_OPT_PEND_BLOCKING,
				  NULL,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Perform capsense meaurement
    	// not touched -1
        // far left 0-6
        // soft left 7-24
        // soft right 25-39
        // hard right >39
        CAPSENSE_Sense();
        sliderPositionRaw = CAPSENSE_getSliderPosition();
        // process slider position
        // TODO figure out force values
        // UNIT TEST 4: making sure Force Values are as expected
        if (sliderPositionRaw < 0)
        	currPendulumForce = SLIDER_NO_FORCE;
        else if (sliderPositionRaw <= 6)
        	currPendulumForce = SLIDER_HARD_LEFT_FORCE;
        else if (sliderPositionRaw <= 24)
        	currPendulumForce = SLIDER_SOFT_LEFT_FORCE;
        else if (sliderPositionRaw <= 39)
        	currPendulumForce = SLIDER_SOFT_RIGHT_FORCE;
        else if (sliderPositionRaw > 39)
        	currPendulumForce = SLIDER_HARD_RIGHT_FORCE;

        // If force has changed, update values in rodParams
        // FUNCTIONAL TEST 5 - set breakpoint on next line of code below if testing //
        // UNIT TEST 10: Making sure force value changed before updating shared data
        if (currPendulumForce != lastPendulumForce)
        {
        	// Acquire rodParams lock
        	OSMutexPend(&PendulumParamsLock,
        			    MUTEX_PEND_FOREVER,
    					OS_OPT_PEND_BLOCKING,
    					NULL,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

			// Quickly update pendulumForce in rodParams
        	rodParams.pendulumForce = currPendulumForce;
        	// UNIT TEST 6: Confirming shared force data was actually updated
        	if (rodParams.pendulumForce != currPendulumForce)
        		while (INFINITE_LOOP);

			// Release lock on rodParams
        	OSMutexPost(&PendulumParamsLock,
        			    OS_OPT_POST_NONE,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        }
        // Update last force value
        lastPendulumForce = currPendulumForce;
    }
}

/**
 * @brief
 * Button Input / LED0 Output Task
 *
 * @details
 * Triggered by GPIO ISR, adjusts force gain coefficient "pendulumForceGain"
 * in rodParams, and also adjusts led0 PWM based on pendulumForceGain, to
 * provide a visual reference.
 *
 */
static void	ButtonInLED0OutTask(void * p_arg)
{
    RTOS_ERR  err;
    uint16_t currPendulumForceGain;
    static uint16_t lastPendulumForceGain = FORCE_GAIN_NONE;
    ButtonMessage rcvd_msg;
    uint16_t currLED0PWM;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // TODO initialize LED0 PWM hardware

    while (INFINITE_LOOP)
    {
    	// Pend on ButtonInLED0OutMsgQ
    	rcvd_msg = * (ButtonMessage *) OSQPend(&ButtonInLED0OutMsgQ,
    									       MSGQ_PEND_FOREVER,
											   OS_OPT_PEND_BLOCKING,
											   NULL,
											   NULL,
											   &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// UNIT TEST 5: confirm buttons are actually adjusting force gain value
    	if (rodParams.pendulumForceGain != lastPendulumForceGain)
    		while (INFINITE_LOOP);

    	// Quickly update pendulumForceGain
    	// UNIT TEST 3: testing force gain boundary conditions (high and low)
    	if 		(rcvd_msg.button == btn0 && (rodParams.pendulumForce + FORCE_GAIN_ADJUST_VALUE) <= FORCE_GAIN_MAX_VALUE)
    		rodParams.pendulumForceGain += FORCE_GAIN_ADJUST_VALUE;
    	else if (rcvd_msg.button == btn1 && rodParams.pendulumForce > FORCE_GAIN_NONE)
    		rodParams.pendulumForceGain -= FORCE_GAIN_ADJUST_VALUE;
    	// get new value (to be used for LED0 PWM)
    	currPendulumForceGain = rodParams.pendulumForceGain;


		// Release lock on rodParams
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// TODO update LED0 PWM with new force gain value
    	currLED0PWM = currPendulumForceGain;
    	// UNIT TEST 8: confirming buttons actualkly adjust LED0 PWM value
    	// TODO update test when PWM implemented
    	if (currLED0PWM != currPendulumForceGain)
    		while (INFINITE_LOOP);

    	lastPendulumForceGain = currPendulumForceGain;
    }
}

/**
 * @brief
 * LED1 Output Task
 *
 * @details
 * In the case of a game violation (either pendulum fell, or base left
 * x-limits of screen), adjusts LED1 and ends game until reset.
 * For pendlm_fell: de-illuminates LED1 and ends game
 * For xmax_violation: blink LED1 at 1Hz and ends game
 *
 * @note
 * Also illuminates LED1 solid at startup
 *
 */
static void	LED1OutTask(void * p_arg)
{
    RTOS_ERR  err;
    OS_FLAGS flaggedViolation;
    CPU_BOOLEAN tmrStartSuccess;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // Illuminate LED1, solid
	GPIO_PinOutSet(LED1_port, LED1_pin);


    while (INFINITE_LOOP)
    {
    	// Pend on led1outflags
    	flaggedViolation = OSFlagPend(&LED1OutFlags,
    			                  FLAG_BOTH_VIOLATIONS,
								  FLAG_PEND_FOREVER,
								  OS_OPT_PEND_FLAG_SET_ANY,
								  NULL,
								  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Parse Violation Type
    	// XMax/XMin Violation
    	if (flaggedViolation == FLAG_XMAX_VIOLATION)
    	{
    		// FUNCTIONAL TEST 2 - set breakpoint on next line of code below if testing //
    	    // Start LED1 Blink Timer
    	    tmrStartSuccess = OSTmrStart(&LED1BlinkTimer,
    	    		   &err);
    		APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    		// UNIT TEST 9D: confirming timer started
    		if (tmrStartSuccess == DEF_FALSE)
    			while(INFINITE_LOOP);
    		// Go into infinite loop, toggling LED1 at 1Hz
    		while (INFINITE_LOOP)
    		{
    			// Pend on LED1 Blink Timer Sem
    	    	OSSemPend(&LED1BlinkTimerSem,
    	    			  SEM_PEND_FOREVER,
    					  OS_OPT_PEND_BLOCKING,
    					  NULL,
    					  &err);
    	    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    			// Toggle LED1
    	    	GPIO_PinOutToggle(LED1_port, LED1_pin);
    		}
    	}
    	// Pendulum Fell Violation
    	if (flaggedViolation == FLAG_PENDLM_FELL_VIOLATION)
    	{
    		// FUNCTIONAL TEST 1 - set breakpoint on next line of code below if testing //
    		// de-illuminate LED1
    		GPIO_PinOutClear(LED1_port, LED1_pin);
    		// enter infinite loop
    		while (INFINITE_LOOP);
    	}
    }
}


